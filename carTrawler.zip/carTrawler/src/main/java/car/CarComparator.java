package car;

import java.util.Comparator;

public class CarComparator implements Comparator<CarResult> {

	public int compare(CarResult o1, CarResult o2) {
		// TODO Auto-generated method stub
		return !o1.getSippCode().equalsIgnoreCase(o2.getSippCode()) ? o1.getSippCode().compareTo(o2.getSippCode())
				: (int) (o1.getRentalCost() - o2.getRentalCost());

	}

}
