package view;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import car.CarComparator;
import car.CarResult;

public class Display {
	public void render(Set<CarResult> cars) {
		List<CarResult> corporateCars = new ArrayList<CarResult>();
		List<CarResult> nonCorporateCars = new ArrayList<CarResult>();
		for (CarResult car : cars) {
			if (car.getSupplierName().equalsIgnoreCase("AVIS") || car.getSupplierName().equalsIgnoreCase("BUDGET")
					|| car.getSupplierName().equalsIgnoreCase("ENTERPRISE")
					|| car.getSupplierName().equalsIgnoreCase("FIREFLY")
					|| car.getSupplierName().equalsIgnoreCase("HERTZ") || car.getSupplierName().equalsIgnoreCase("SIXT")
					|| car.getSupplierName().equalsIgnoreCase("THRIFTY")) {
				corporateCars.add(car);

			} else {
				nonCorporateCars.add(car);

			}
		}
		
		Collections.sort(corporateCars, new CarComparator());
		Collections.sort(nonCorporateCars, new CarComparator());
		List<CarResult> corpNonCorpCarSortedList=new ArrayList<CarResult>(corporateCars);
		corpNonCorpCarSortedList.addAll(nonCorporateCars);
		for(CarResult car: corpNonCorpCarSortedList)
		{
			System.out.println(car.getSupplierName()+" "+car.getDescription()+" "+car.getSippCode()+" "+car.getRentalCost()+" "+car.getFuelPolicy());
		}
	}
}
