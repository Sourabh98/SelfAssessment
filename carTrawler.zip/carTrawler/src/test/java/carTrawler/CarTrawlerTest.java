package carTrawler;

import java.util.HashSet;
import java.util.Set;
import java.util.logging.Logger;

import org.junit.Assert;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import car.CarResult;

class CarTrawlerTest {

	static Set<CarResult> CARS;

	static Logger log = Logger.getAnonymousLogger();

	@BeforeAll
	public static void setUp() {
		log.info("startup");
		CARS = new HashSet<CarResult>();
		CARS.add(new CarResult("Volkswagen Polo", "NIZA", "EDMR", 12, CarResult.FuelPolicy.FULLEMPTY));
		CARS.add(new CarResult("Volkswagen Polo", "NIZA", "EDMR", 12.81d, CarResult.FuelPolicy.FULLEMPTY));

	}

	@Test
	public void duplicateCarTest() {
		Assert.assertEquals(1, CARS.size());

	}

	@AfterAll
	public static void tearDown() {
		log.info("tearDown");
		CARS.clear();
	}

}
